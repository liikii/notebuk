#词汇表

统一特殊词汇的翻译标准，请按字典序记录。

##a

| 英文 | 中文 |
|------|------|
|address space | 地址空间|
|allocator | 分配器|

##b

| 英文 | 中文 |
|------|------|
|boot loader | 引导加载器 |
| buffer cache | 缓冲器高速缓存，块缓冲 |

##c

| 英文 | 中文 |
|------|------|
|(sleep/wakeup) channel | (睡眠/唤醒)队列|
|console | 控制台|
|context | 上下文|
|convoy | 护航|
|coroutine | 共行程序|

##d

| 英文 | 中文 |
|------|------|
|disk | 磁盘|

##e

##f

| 英文 | 中文 |
|------|------|
|free list | 空闲链表|

##g

| 英文 | 中文 |
|------|------|
|guard page | 保护页|

##h

| 英文 | 中文 |
|------|------|
|hardware privilege | 硬件特权|

##i

| 英文 | 中文 |
| --- | -----|
| inode | i 节点 |

##j

##k

| 英文 | 中文 |
|------|------|
|kernel | 内核|

##l

| 英文 | 中文 |
|------|------|
|logical address | 逻辑地址|
|lost wakeup | 丢失的唤醒|

##m

| 英文 | 中文 |
|------|------|
|multiplex | 多路复用|
|motherboard | 主板 |

##n

##o

| 英文 | 中文 |
| ----|----|
| on-disk | 磁盘上|
| in-memory | 内存中|

##p

| 英文 | 中文 |
|------|------|
|page table | 页表|
|page table entry | 页表条目|
|paging hardwre | 分页硬件|
|per-cpu | per-cpu|
|pipe | 管道|
|pre-arranged | 预定义|
|previlege level | 特权级 |
|PC-relative direct jump | PC 相关的直接跳转 |

##q

##r

| 英文 | 中文 |
|------|------|
|real world | 现实情况|
|rendezvous point | 集合点|

##s

| 英文 | 中文 |
|------|------|
|segment hardware | 分段硬件|
|semaphore | 信号量|
|shell | shell|
|system call | 系统调用|

##t

| 英文 | 中文 |
|------|------|
|thundering herd | 惊群|
|time-sharing | 分时|
|task state segment | 任务状态段 |

##u

| 英文 | 中文 |
|------|------|
|unwind (stack) | 展开（栈）|

##v

##w

##x

##y

##z


