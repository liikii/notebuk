###原文档错误

1. 50页：“To avoid this situation ...”段中，"(cli is the x86 ..." 缺少后括号。
2. 65页：最后一段倒数第4行，“process may send a signal to it.” 排版有误。
3. 51页：“For example ...”段中，倒数第4行的 "than" 应为 "then"。